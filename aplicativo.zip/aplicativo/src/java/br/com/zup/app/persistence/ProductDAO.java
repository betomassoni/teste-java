/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.zup.app.persistence;

import br.com.zup.app.entities.Product;
import br.com.zup.app.impl.DAOImpl;


/**
 *
 * @author roberto.massoni
 */
public class ProductDAO extends DAOImpl<Product> {

}
