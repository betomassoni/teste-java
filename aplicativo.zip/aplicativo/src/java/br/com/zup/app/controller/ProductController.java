/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.zup.app.controller;

import br.com.caelum.vraptor.Controller;
import br.com.caelum.vraptor.Delete;
import br.com.caelum.vraptor.Get;
import br.com.caelum.vraptor.Path;
import br.com.caelum.vraptor.Post;
import br.com.caelum.vraptor.Put;
import br.com.caelum.vraptor.Result;
import static br.com.caelum.vraptor.view.Results.json;
import br.com.zup.app.persistence.ProductDAO;
import br.com.zup.app.entities.Product;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.inject.Inject;
import org.hibernate.Session;
import br.com.zup.app.util.AppResponse;
import java.util.ArrayList;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

  
/**
 *
 * @author roberto.massoni
 */
@Controller
@Path("products")
public class ProductController {

    @Inject
    private ProductDAO dao;
    @Inject 
    private Result result; 
    @Inject
    private Session session;

    @Get 
    @Path("")
    public void getAll() {
        try { 
            List<Product> productList = dao.list(this.session, Product.class, null, null);
            this.result.use(json()).indented().withoutRoot().from(productList).serialize();
        } catch (Exception ex) {
            Logger.getLogger(ProductController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     
    @Get
    @Path("/{id}")
    public void get(int id) {
        try {  
            List<Criterion> criterionList = new ArrayList();
            criterionList.add(Restrictions.eq("id", id));            
            
            Product product = dao.get(this.session, Product.class, id);            
            this.result.use(json()).indented().withoutRoot().from(product).serialize();
        } catch (Exception ex) {
            Logger.getLogger(ProductController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @Post
    @Path("")
    public void insert(Product product) {
        try {              
            AppResponse response = dao.insert(this.session, product);            
            this.result.use(json()).indented().withoutRoot().from(response).serialize();
        } catch (Exception ex) {
            Logger.getLogger(ProductController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @Put
    @Path("/{id}")
    public void edit(int id, Product product) {
        try {
            //TODO
            product.setId(id);
            
            AppResponse response = dao.update(this.session, product);            
            this.result.use(json()).indented().withoutRoot().from(response).serialize();
        } catch (Exception ex) {
            Logger.getLogger(ProductController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @Delete
    @Path("/{id}")
    public void delete(int id) {
        try {            
            AppResponse response = dao.delete(this.session, new Product(id));            
            this.result.use(json()).indented().withoutRoot().from(response).serialize();
        } catch (Exception ex) {
            Logger.getLogger(ProductController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
