/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.zup.app.impl;

import br.com.zup.app.util.AppResponse;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;


/**
 *
 * @author roberto.massoni
 */
public interface DAOService<E> {
    public AppResponse insert(Session session, E entity) throws Exception;
    public AppResponse update(Session session, E entity) throws Exception;
    public AppResponse delete(Session session, E entity) throws Exception;
    public List<E> list(Session session, Class entityClass, List<Order> orderList, List<Criterion> simpleExpressionList) throws Exception;
    public E get(Session session, Class entityClass, int id) throws Exception;
}
