/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.zup.app.util;

import java.io.Serializable;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.inject.Disposes;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

/**
 *
 * @author roberto.massoni
 */
@RequestScoped
public class HibernateSessionFactory implements Serializable {

    @Inject
    private SessionFactory sessionFactory;

    @Produces 
    @RequestScoped
    public Session getSession() {
        return this.sessionFactory.openSession();
    }

    public void closeSession(@Disposes Session session) {
        if (session.isOpen()) {
            session.close();
        }
    }
}
