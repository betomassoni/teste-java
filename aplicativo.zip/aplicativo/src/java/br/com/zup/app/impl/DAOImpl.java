/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.zup.app.impl;

import br.com.zup.app.util.AppResponse;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;


/**
 *
 * @author roberto.massoni
 */
public class DAOImpl<E> implements DAOService<E> {

    @Override
    public AppResponse insert(Session session, E entity) {

        AppResponse response = new AppResponse();

        if (entity == null) {
            response.setType("warning");
            response.setMessage("Registro não informado");
        }

        try {
            session.save(entity);
            response.setType("success");
            response.setMessage("Registro incluído com sucesso");
            session.beginTransaction().commit();
        } catch (Exception ex) {
            response.setType("error");
            response.setMessage("Não foi possível incluír o registro");
        }
        return response;
    }

    @Override
    public AppResponse update(Session session, E entity) {

        AppResponse response = new AppResponse();

        if (entity == null) {
            response.setType("warning");
            response.setMessage("Registro não informado");
        }

        try {
            session.update(entity);
            response.setType("success");
            response.setMessage("Registro alterado com sucesso");
            session.beginTransaction().commit();
        } catch (Exception ex) {
            response.setType("error");
            response.setMessage("Não foi possível alterar o registro");
        }
        return response;
    }

    @Override
    public AppResponse delete(Session session, E entity) {
        AppResponse response = new AppResponse();

        if (entity == null) {
            response.setType("warning");
            response.setMessage("Registro não informado");
        }

        try {
            session.delete(entity);
            response.setType("success");
            response.setMessage("Registro excluído com sucesso");
            session.beginTransaction().commit();

        } catch (Exception ex) {
            response.setType("error");
            response.setMessage("Erro: " + ex.getMessage());
        }
        return response;
    }

    @Override
    public List<E> list(Session session, Class entityClass, List<Order> orderList, List<Criterion> criterios) throws Exception {

        try {
            
            Criteria criteria = session.createCriteria(entityClass);

            if (orderList != null) {
                for (Order order : orderList) {
                    criteria.addOrder(order);
                }
            }
            
            if (criterios != null) {
                for (Criterion criterio : criterios) {
                    criteria.add(criterio);
                }
            }

            return criteria.list();

        } catch (Exception ex) {
            throw new Exception("Error: " + ex.getMessage());
        }

    }

    @Override
    public E get(Session session, Class entityClass, int id) throws Exception {

        try {
            return (E) session.get(entityClass, id);
        } catch (Exception ex) {
            throw new Exception("Error: " + ex.getMessage());
        }

    }

}
