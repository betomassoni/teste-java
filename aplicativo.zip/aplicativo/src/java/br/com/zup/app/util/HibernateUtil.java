/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.zup.app.util;

import java.io.File;
import java.io.Serializable;
import java.util.ResourceBundle;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author roberto.massoni
 */
public class HibernateUtil implements Serializable {

    private static final long serialVersionUID = 1L;
    private static final Configuration cfg;    
    private static SessionFactory sessionFactory;    

    static {
        cfg = getConfiguration();        
        sessionFactory = cfg.buildSessionFactory();
    }
    
    private static SessionFactory buildSessionFactory() {
        try {
            // Create the SessionFactory from hibernate.cfg.xml
            return new Configuration().configure(new File("hibernate.cfg.xml")).buildSessionFactory();
        } catch (Throwable ex) {
            // Make sure you log the exception, as it might be swallowed
            System.err.println("Initial SessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex); 
        }
    }
    
    private static Configuration getConfiguration() {
        Configuration configuration = new Configuration();
        try {
            ResourceBundle resourceBundle = ResourceBundle.getBundle("config");
            String dataBase = resourceBundle.getString("DATA_BASE");
            configuration.configure("/" + dataBase);             
        } catch (Exception ex) {
            System.out.println(ex.getMessage());            
            configuration.configure();
        }
        return configuration;
    }
    
    public static void closeSessionFactory() {
        sessionFactory.close();        
    }
    
    public static SessionFactory getSessionFactory() {
        if (sessionFactory.isClosed())
            sessionFactory = cfg.buildSessionFactory();
        return sessionFactory;
    }

    public static Session getSession() {
        return sessionFactory.openSession();
    }
   
}
