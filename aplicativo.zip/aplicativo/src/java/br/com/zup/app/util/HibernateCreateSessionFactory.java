/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.zup.app.util;

import java.io.Serializable;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Disposes;
import javax.enterprise.inject.Produces;
import org.hibernate.SessionFactory;

/**
 *
 * @author roberto.massoni
 */
@ApplicationScoped
public class HibernateCreateSessionFactory implements Serializable {

    @Produces
    @ApplicationScoped
    public SessionFactory getSessionFactory() {
        return HibernateUtil.getSessionFactory();
    }

    public void closeSessionFactory(@Disposes SessionFactory sessionFactory) {
        sessionFactory.close();
    }
}
