/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.zup.app.controller;

import br.com.zup.app.entities.Product;
import junit.framework.TestCase;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.hamcrest.CoreMatchers;
import static org.junit.Assert.assertThat;

/**
 *
 * @author robertomassoni
 */
public class ProductControllerTest extends TestCase {
    
    public ProductControllerTest(String testName) {
        super(testName);
    }

    /**
     * Test of getAll method, of class ProductController.
     */
    public void testGetAll() {
        System.out.println("getAll");
//        
        Client client = ClientBuilder.newClient();
        Response response = client
                    .target("http://localhost:8084/aplicativo")
                    .path("/products")
                    .request(MediaType.APPLICATION_JSON)
                    .get();

            System.out.println(response.toString());
//            System.out.println(response.readEntity(String.class));
            
        assertThat(response.toString(), CoreMatchers.containsString("200"));
    }

    /**
     * Test of get method, of class ProductController.
     */
    public void testGet() {
        System.out.println("get");
        
        int product = 1;
        Client client = ClientBuilder.newClient();
        Response response = client
                    .target("http://localhost:8084/aplicativo")
                    .path("/products/" + product)
                    .request(MediaType.APPLICATION_JSON)
                    .get();

            System.out.println(response.getStatus());
//            System.out.println(response.readEntity(String.class));
            
            
        assertThat(response.toString(), CoreMatchers.containsString("200"));
    }

    /**
     * Test of insert method, of class ProductController.
     */
    public void testInsert() {
        System.out.println("insert");
        
        Form form = new Form();
        form.param("product.name", "Desktop");
        form.param("product.description", "Desktop description");
        form.param("product.category", "Eletronic");
        form.param("product.price", "742");
        
        Client client = ClientBuilder.newClient();
        Response response = client
                    .target("http://localhost:8084/aplicativo")
                    .path("/products")
                    .request(MediaType.APPLICATION_FORM_URLENCODED)
                    .post(Entity.form(form));

            System.out.println(response.getStatus());
//            System.out.println(response.readEntity(String.class));
            
        assertThat(response.readEntity(String.class), CoreMatchers.containsString("success"));  
    }

    /**
     * Test of edit method, of class ProductController.
     */
    public void testEdit() {
        System.out.println("edit");
        
        int id = 10;       
        Form form = new Form();
        form.param("product.name", "Notebook");
        form.param("product.description", "Notebook description");
        form.param("product.category", "Eletronic");
        form.param("product.price", "742");
        
        Client client = ClientBuilder.newClient();
        Response response = client
                    .target("http://localhost:8084/aplicativo")
                    .path("/products/" + id)
                    .request(MediaType.APPLICATION_FORM_URLENCODED)
                    .put(Entity.form(form));

            System.out.println(response.getStatus());
//            System.out.println(response.readEntity(String.class));
            
                assertThat(response.readEntity(String.class), CoreMatchers.containsString("success"));
    }

    /**
     * Test of delete method, of class ProductController.
     */
    public void testDelete() {
        System.out.println("delete");
        int id = 22;
        Client client = ClientBuilder.newClient();
        Response response = client
                    .target("http://localhost:8084/aplicativo")
                    .path("/products/" + id)
                    .request(MediaType.APPLICATION_JSON)
                    .delete();

            System.out.println(response.getStatus());            
//            System.out.println(response.readEntity(String.class));
            
            assertThat(response.readEntity(String.class), CoreMatchers.containsString("success"));       
    }
    
}
